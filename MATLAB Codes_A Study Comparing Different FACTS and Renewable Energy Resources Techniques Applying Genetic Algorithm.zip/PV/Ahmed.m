 function LPT= Ahmed(x)
xx(1) = round(x(1))
xx(2) = x(2) 
nrlfppg
end