x = ['One shunt capacitor' 'Two shunt capacitors' 'One series capacitor' 'Two series capacitors' 'One Series' 0.75 33.66 36.16 33.66];
y = [0.34 0.52 0.13 0.25 0.46 0.75 33.66 36.16 33.66];
plot(x,y)