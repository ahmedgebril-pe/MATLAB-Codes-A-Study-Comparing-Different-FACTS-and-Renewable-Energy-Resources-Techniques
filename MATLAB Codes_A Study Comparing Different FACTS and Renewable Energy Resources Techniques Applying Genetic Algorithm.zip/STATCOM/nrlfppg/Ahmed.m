 function Lpigt= Ahmed(x)
xx=x
nrlfppg
end