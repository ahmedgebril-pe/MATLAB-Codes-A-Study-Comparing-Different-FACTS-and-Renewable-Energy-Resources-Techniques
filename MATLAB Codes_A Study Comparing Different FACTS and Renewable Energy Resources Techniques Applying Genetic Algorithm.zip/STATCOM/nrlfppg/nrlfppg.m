% Program for Newton-Raphson Load Flow Analysis..
% Ref Book: Power System Analysis by Hadi Saadat..
% Code by Praviraj PG, First Version - Jan-2007
% Rev 1 - Jan-2018: Updated LOADFLOW.M
% Rev 2 - May-2020: Added GRAPHPLOT.M

num = 30;   % IEEE-14, IEEE-30, IEEE-57, 118..
Y = ybusppg(num);           % Calling ybusppg.m to get Bus Admittance Matrix..
busd = busdatas(num);       % Calling busdata30.m to get busdatas..
BMva = 100;                 % Base MVA..
bus = busd(:,1);            % Bus Number..
type = busd(:,2);           % Type of Bus 1-Slack, 2-PV, 3-PQ..
V = busd(:,3);              % Specified Voltage..
del = zeros(length(V),1);   % Voltage Angle..
Pg = busd(:,5)/BMva;        % PGi..
Qg = busd(:,6)/BMva;        % QGi..
Pl = busd(:,7)/BMva;        % PLi..
Ql = busd(:,8)/BMva;        % QLi..
Qmin = busd(:,9)/BMva;      % Minimum Reactive Power Limit..
Qmax = busd(:,10)/BMva;     % Maximum Reactive Power Limit..
nbus = max(bus);            % To get no. of buses..
P = Pg - Pl;                % Pi = PGi - PLi..
Q = Qg - Ql;                % Qi = QGi - QLi..
Psp = P;                    % P Specified       
Qsp = Q;                    % Q Specified
G = real(Y);                % Conductance..
B = imag(Y);                % Susceptance..
Vsp = V;

% Details of STATCOM
statb = xx(1); % Buses at which statcoms are placed..
Vsh = xx(2);
Thst = xx(3);
gsh = xx(4);
bsh = xx(5);
Vshmx = 1.1; Vshmn = 0.9;
Thstmx = pi; Thstmn = -pi;
np = length(statb); % Number of STATCOMs..

pv = find(type == 2 | type == 1);       % Index of PV Buses..
pq = find(type == 3);                   % Index of PQ Buses..
npv = length(pv);                       % Number of PV buses..
npq = length(pq);                       % Number of PQ buses..

Tol = 1;  
Iter = 1;           % iteration starting
while (Tol > 1e-5 && Iter <= 50)   % Iteration starting..
    P = zeros(nbus,1);
    Q = zeros(nbus,1);
    % Calculate P and Q
    for i = 1:nbus
        for k = 1:nbus
            P(i) = P(i) + V(i)* V(k)*(G(i,k)*cos(del(i)-del(k)) + B(i,k)*sin(del(i)-del(k)));
            Q(i) = Q(i) + V(i)* V(k)*(G(i,k)*sin(del(i)-del(k)) - B(i,k)*cos(del(i)-del(k)));
        end
                m = find(statb == i);
        if ~isempty(m)
            P(i) = P(i) + V(i)^2*gsh - V(i)*Vsh(m)*(gsh*cos(del(i)-Thst(m)) + bsh*sin(del(i)-Thst(m)));
            Q(i) = Q(i) - V(i)^2*bsh - V(i)*Vsh(m)*(gsh*sin(del(i)-Thst(m)) - bsh*cos(del(i)-Thst(m)));
        end
    end

    % Checking Q-limit violations..
    if Iter <= 7 && Iter > 2    % Only checked up to 7th iterations..
        for n = 2:nbus
            if type(n) == 2
                QG = Q(n)+Ql(n);
                if QG < Qmin(n)
                    V(n) = V(n) + 0.01;
                elseif QG > Qmax(n)
                    V(n) = V(n) - 0.01;
                end
            end
         end
    end
    
 % Calculating Pst, 
    Pst = zeros(np,1);
    for i = 1:np
        m = statb(i);
        Pst(i) = Vsh(i)^2*gsh - V(m)*Vsh(i)*(gsh*cos(Thst(i)-del(m)) + bsh*sin(Thst(i)-del(m)));
    end
    
    % Calculate Qst
    Qst = zeros(np,1);
    for i = 1:np
        m = statb(i);
        Qst(i) = - Vsh(i)^2*gsh - V(m)*Vsh(i)*(gsh*sin(Thst(i)-del(m)) - bsh*cos(Thst(i)-del(m)));
    end
    
    % Calculate change from specified value
    dPa = Psp-P;
    dQa = Qsp-Q;
    dQ = zeros(npq,1);
    k = 1;
    for i = 1:nbus
        if type(i) == 3
            dQ(k,1) = dQa(i);
            k = k+1;
        end
    end
    dP = dPa(2:nbus);
    dPst = -Pst;
    dQst = -Qst;
    M = [dP; dQ; dPst; dQst];       % Mismatch Vector
    
    % Jacobian
    % J11 - Derivative of Real Power Injections with Angles..
    J11 = zeros(nbus-1,nbus-1);
    for i = 1:(nbus-1)
        m = i+1;
        p = find(statb == m);
        for k = 1:(nbus-1)
            q = k+1;
            if q == m
                for n = 1:nbus
                    J11(i,k) = J11(i,k) + V(m)* V(n)*(-G(m,n)*sin(del(m)-del(n)) + B(m,n)*cos(del(m)-del(n)));
                end
                J11(i,k) = J11(i,k) - V(m)^2*B(m,m);
                if ~isempty(p)
                    J11(i,k) = J11(i,k) + V(m)*Vsh(p)*(gsh*sin(del(m)-Thst(p)) - bsh*cos(del(m)-Thst(p)));
                end
            else
                J11(i,k) = V(m)* V(q)*(G(m,q)*sin(del(m)-del(q)) - B(m,q)*cos(del(m)-del(q)));
            end
        end
    end
    
    % J12 - Derivative of Real Power Injections with V..
    J12 = zeros(nbus-1,npq);
    for i = 1:(nbus-1)
        m = i+1;
        p = find(statb == m);
        for k = 1:npq
            q = pq(k);
            if q == m
                for n = 1:nbus
                    J12(i,k) = J12(i,k) + V(n)*(G(m,n)*cos(del(m)-del(n)) + B(m,n)*sin(del(m)-del(n)));
                end
                J12(i,k) = J12(i,k) + V(m)*G(m,m);
                if ~isempty(p)
                    J12(i,k) = J12(i,k) + 2*V(m)*gsh - Vsh(p)*(gsh*cos(del(m)-Thst(p)) + bsh*sin(del(m)-Thst(p)));
                end
            else
                J12(i,k) = V(m)*(G(m,q)*cos(del(m)-del(q)) + B(m,q)*sin(del(m)-del(q)));
            end
        end
    end
    
    % J13 - Derivative of Real Power Injections with Thst..
    % J14 - Derivative of Real Power Injections with Vsh..
    J13 = zeros(nbus-1,np);
    J14 = zeros(nbus-1,np);
    for i = 1:(nbus-1)
        m = i+1;
        for k = 1:np
            p = statb(k);
            if m == p
                J13(i,k) = -V(m)*Vsh(k)*(gsh*sin(del(m)-Thst(k)) - bsh*cos(del(m)-Thst(k)));
                J14(i,k) = -V(m)*(gsh*cos(del(m)-Thst(k)) + bsh*sin(del(m)-Thst(k)));
            end
        end
    end
    
    % J21 - Derivative of Reactive Power Injections with Angles..
    J21 = zeros(npq,nbus-1);
    for i = 1:npq
        m = pq(i);
        p = find(statb == m);
        for k = 1:(nbus-1)
            q = k+1;
            if q == m
                for n = 1:nbus
                    J21(i,k) = J21(i,k) + V(m)* V(n)*(G(m,n)*cos(del(m)-del(n)) + B(m,n)*sin(del(m)-del(n)));
                end
                J21(i,k) = J21(i,k) - V(m)^2*G(m,m);
                if ~isempty(p)
                    J21(i,k) = J21(i,k) - V(m)*Vsh(p)*(gsh*cos(del(m)-Thst(p)) + bsh*sin(del(m)-Thst(p)));
                end
            else
                J21(i,k) = -V(m)* V(q)*(G(m,q)*cos(del(m)-del(q)) + B(m,q)*sin(del(m)-del(q)));
            end
        end
    end
    
    % J22 - Derivative of Reactive Power Injections with V..
    J22 = zeros(npq,npq);
    for i = 1:npq
        m = pq(i);
        p = find(statb == m);
        for k = 1:npq
            q = pq(k);
            if q == m
                for n = 1:nbus
                    J22(i,k) = J22(i,k) + V(n)*(G(m,n)*sin(del(m)-del(n)) - B(m,n)*cos(del(m)-del(n)));
                end
                J22(i,k) = J22(i,k) - V(m)*B(m,m);
                if ~isempty(p)
                    J22(i,k) = J22(i,k) - 2*V(m)*bsh - Vsh(p)*(gsh*sin(del(m)-Thst(p)) - bsh*cos(del(m)-Thst(p)));
                end
            else
                J22(i,k) = V(m)*(G(m,q)*sin(del(m)-del(q)) - B(m,q)*cos(del(m)-del(q)));
            end
        end
    end
    
    % J23 - Derivative of Reactive Power Injections with Thst..
    % J24 - Derivative of Reactive Power Injections with Vsh..
    J23 = zeros(npq,np);
    J24 = zeros(npq,np);
    for i = 1:npq
        q = pq(i);
        m = i+1;
        for k = 1:np
            p = statb(k);
            if q == p
                J23(i,k) = -V(m)*Vsh(k)*(-gsh*cos(del(m)-Thst(k)) + bsh*sin(del(m)-Thst(k)));
                J24(i,k) = -V(m)*(gsh*sin(del(m)-Thst(k)) - bsh*cos(del(m)-Thst(k)));
            end
        end
    end
    
%     J31 - Derivative of Pst with Angles..
%     J41 - Derivative of Qst with Angles..
    J31 = zeros(np,nbus-1);
    J41 = zeros(np,nbus-1);
    for i = 1:np
        m = statb(i);
        for k = 1:(nbus-1)
            if m == k+1
                J31(i,k) = -V(m)*Vsh(i)*(gsh*sin(Thst(i)-del(m)) - bsh*cos(Thst(i)-del(m)));
                J41(i,k) = -V(m)*Vsh(i)*(-gsh*cos(Thst(i)-del(m)) - bsh*sin(Thst(i)-del(m)));
            end
        end
    end
    
%     J32 - Derivative of Pst with V..
%     J42 - Derivative of Qst with V..
    J32 = zeros(np,npq);
    J42 = zeros(np,npq);
    for i = 1:np
        m = statb(i);
        for k = 1:npq
            if m == pq(k)
                J32(i,k) = -Vsh(i)*(gsh*cos(Thst(i)-del(m)) + bsh*sin(Thst(i)-del(m)));
                J42(i,k) = -Vsh(i)*(gsh*sin(Thst(i)-del(m)) - bsh*cos(Thst(i)-del(m)));
            end
        end
    end
    
    % J33 - Derivative of Pst with Thst..
    % J34 - Derivative of Pst with Vsh..
    % J43 - Derivative of Qst with Thst..
    % J44 - Derivative of Qst with Vsh..
    J33 = zeros(np,np);
    J34 = zeros(np,np);
    J43 = zeros(np,np);
    J44 = zeros(np,np);
    for i = 1:np
        m = statb(i);
        for k = 1:np
            p = statb(k);
            if m == p
                J33(i,k) = -V(m)*Vsh(k)*(-gsh*sin(Thst(k)-del(m)) + bsh*cos(Thst(k)-del(m)));
                J34(i,k) = 2*Vsh(k)*gsh - V(m)*(gsh*cos(Thst(k)-del(m)) + bsh*sin(Thst(k)-del(m)));
                J43(i,k) = -V(m)*Vsh(k)*(gsh*cos(Thst(k)-del(m)) + bsh*sin(Thst(k)-del(m)));
                J44(i,k) = -2*Vsh(k)*gsh - V(m)*(gsh*sin(Thst(k)-del(m)) - bsh*cos(Thst(k)-del(m)));
            end
        end
    end
    
    J = [J11 J12 J13 J14; J21 J22 J23 J24; J31 J32 J33 J34; J41 J42 J43 J44];     % Jacobian
    %clear J11 J12 J13 J14 J21 J22 J23 J24 J31 J32 J33 J34 J41 J42 J43 J44
    
    X = inv(J)*M;           % Correction Vector
    dTh = X(1:nbus-1);
    dV = X(nbus:nbus+npq-1);
    dThst = X(nbus+npq:nbus+npq+np-1);
    dVsh = X(nbus+npq+np:nbus+npq+2*np-1);
    del(2:nbus) = dTh + del(2:nbus);
    k = 1;
    for i = 2:nbus
        if type(i) == 3
            V(i) = dV(k) + V(i);
            k = k+1;
        end
    end
    Thst = Thst + dThst;
    Vsh = Vsh + dVsh;

    % Calculate Qsh..
    Qsh = zeros(np,1);
    for m = 1:np
        i = statb(m);
        Qsh(m) = -V(i)^2*bsh + V(i)*Vsh(m)*(bsh*cos(del(i)-Thst(m)) - gsh*sin(del(i)-Thst(m)));
    end
    Iter = Iter + 1;
    Tol = max(abs(M));
end
Del = 180/pi*del;   % Convert radians to degrees

% Call LoadFlow
[fb, tb, Pij, Qij, Lpigt] = loadflow(num,V,del,BMva);      

Iter = Iter - 1; % Number of Iterations took..
V;
Del = 180/pi*del;
Thst = 180/pi*Thst;
E2 = [V Del]; % Bus Voltages and angles..

