 function LPT= Ahmed(x)
xx=x
nrlfppg
end